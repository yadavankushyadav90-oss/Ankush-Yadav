# Customer Churn Prediction

A beginner-friendly machine-learning project with a Streamlit web interface.

## Requirements
- Windows 10/11
- Python 3.10 or newer (Python 3.12/3.13 recommended)
- Internet for installing packages the first time

## Run on Windows
1. Extract the ZIP folder.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Run these commands one by one:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, use Command Prompt terminal and run:
```bat
.venv\Scripts\activate.bat
pip install -r requirements.txt
streamlit run app.py
```

A browser tab will open. Use `sample_customers.csv` to test, or upload your own CSV.
The target column should have two classes, such as `Churn` = Yes/No.

## Files
- `app.py` — app and model training/prediction
- `sample_customers.csv` — small example dataset for testing
- `requirements.txt` — Python packages
