import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

st.set_page_config(page_title="Customer Churn Prediction", page_icon="📊", layout="wide")
st.title("📊 Customer Churn Prediction")
st.write("Predict which customers may leave a service using a CSV dataset.")

@st.cache_data
def load_data(uploaded_file):
    return pd.read_csv(uploaded_file)

uploaded = st.file_uploader("Upload customer CSV dataset", type=["csv"])
if uploaded is None:
    st.info("No dataset? Download/use the sample file `sample_customers.csv` included with this project.")
    default_path = os.path.join(os.path.dirname(__file__), "sample_customers.csv")
    if os.path.exists(default_path):
        df = pd.read_csv(default_path)
    else:
        st.stop()
else:
    df = load_data(uploaded)

st.subheader("1. Dataset preview")
st.dataframe(df.head(10), use_container_width=True)
st.caption(f"Rows: {len(df)} | Columns: {len(df.columns)}")

target = st.selectbox("Choose the target column (the column indicating churn)", df.columns,
                      index=list(df.columns).index("Churn") if "Churn" in df.columns else len(df.columns)-1)
if df[target].nunique(dropna=True) != 2:
    st.error("The target column must contain exactly two classes (for example Yes/No or 1/0).")
    st.stop()

X = df.drop(columns=[target]).copy()
y = df[target].astype(str).fillna("Unknown")
# Remove common customer ID fields, which usually do not help prediction.
id_cols = [c for c in X.columns if c.strip().lower() in {"customerid", "customer_id", "id"}]
X = X.drop(columns=id_cols, errors="ignore")

# Convert numeric-looking object columns to numbers where possible.
for c in X.select_dtypes(include=["object"]).columns:
    converted = pd.to_numeric(X[c], errors="coerce")
    if converted.notna().mean() > 0.85:
        X[c] = converted

numeric_features = X.select_dtypes(include=["number", "bool"]).columns.tolist()
categorical_features = [c for c in X.columns if c not in numeric_features]
numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                             ("onehot", OneHotEncoder(handle_unknown="ignore"))])
transformers = []
if numeric_features:
    transformers.append(("num", numeric_pipe, numeric_features))
if categorical_features:
    transformers.append(("cat", categorical_pipe, categorical_features))
preprocess = ColumnTransformer(transformers=transformers)
model = Pipeline([("preprocess", preprocess),
                  ("classifier", RandomForestClassifier(n_estimators=200, random_state=42,
                                                        class_weight="balanced"))])

st.subheader("2. Train and evaluate")
test_size = st.slider("Test data (%)", min_value=10, max_value=40, value=20, step=5)
if st.button("Train model", type="primary"):
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size/100, random_state=42, stratify=y
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        acc = accuracy_score(y_test, preds)
        c1, c2, c3 = st.columns(3)
        c1.metric("Accuracy", f"{acc:.1%}")
        c2.metric("Training rows", len(X_train))
        c3.metric("Test rows", len(X_test))
        st.write("**Classification report**")
        st.code(classification_report(y_test, preds, zero_division=0))
        labels = sorted(y.unique())
        cm = confusion_matrix(y_test, preds, labels=labels)
        st.write("**Confusion matrix** (rows = actual, columns = predicted)")
        st.dataframe(pd.DataFrame(cm, index=[f"Actual {v}" for v in labels],
                                  columns=[f"Predicted {v}" for v in labels]))
        st.session_state["trained_model"] = model
        st.session_state["feature_columns"] = X.columns.tolist()
        st.session_state["target_name"] = target
        st.session_state["positive_class"] = sorted(y.unique())[-1]
        st.success("Model trained. You can now try a customer prediction below.")
    except Exception as e:
        st.error(f"Could not train model: {e}")
        st.info("Make sure both target classes have enough rows and the CSV has no empty target values.")

if "trained_model" in st.session_state:
    st.subheader("3. Predict a customer")
    st.write("Enter customer details below. Leave fields at their defaults if you are just testing.")
    inputs = {}
    for col in st.session_state["feature_columns"]:
        if col in numeric_features:
            vals = pd.to_numeric(X[col], errors="coerce").dropna()
            default = float(vals.median()) if len(vals) else 0.0
            inputs[col] = st.number_input(col, value=default)
        else:
            vals = X[col].dropna().astype(str).unique().tolist()
            options = vals if vals else ["Unknown"]
            inputs[col] = st.selectbox(col, options=options, key=f"pred_{col}")
    if st.button("Predict churn"):
        one = pd.DataFrame([inputs], columns=st.session_state["feature_columns"])
        prediction = st.session_state["trained_model"].predict(one)[0]
        st.metric("Predicted class", str(prediction))
        if hasattr(st.session_state["trained_model"], "predict_proba"):
            probabilities = st.session_state["trained_model"].predict_proba(one)[0]
            classes = st.session_state["trained_model"].named_steps["classifier"].classes_
            prob_df = pd.DataFrame({"Class": classes, "Probability": probabilities})
            st.dataframe(prob_df, use_container_width=True)
        st.caption("Predictions are estimates, not guarantees. Check data quality and fairness before using in real business decisions.")

st.subheader("About this project")
st.markdown("""
- **Goal:** identify customers who may stop using a service.
- **Algorithm:** Random Forest classifier.
- **Preprocessing:** missing-value imputation, numeric scaling, categorical one-hot encoding.
- **Metrics:** accuracy, precision, recall, F1-score and confusion matrix.
""")
